export class User {
    username: string;
    firstName: string;
    lastName: string;
    email: string;
    access_token: string;
    refresh_tokent: string;
    expires_at: Date;
    expires_in: number;
}
