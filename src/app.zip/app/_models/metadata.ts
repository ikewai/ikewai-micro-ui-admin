export class Metadata {
  uuid: string;
  value: [];
  name: string;
}
